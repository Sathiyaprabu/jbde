package com.jbde.exception;

public class JbdeAccessDeniedException extends RuntimeException{

	public JbdeAccessDeniedException(String message){
		super(message);
		
	}
	
}
