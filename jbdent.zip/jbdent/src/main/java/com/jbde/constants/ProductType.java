package com.jbde.constants;

public enum ProductType {
	YT_VIDEO,
	FB_VIDEO,
	YT_SHORTS,
	FB_SHORTS,
	YT_REELS,
	IG_REELS,
	FB_REELS,
	MOJ_REELS,
	COMMON_REELS,
	OTHER_REELS
	
	
}
