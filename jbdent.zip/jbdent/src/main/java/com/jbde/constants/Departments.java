package com.jbde.constants;

public enum Departments {
	MANAGEMENT,
	EDITING,
	CINEMATOGRAPHY,
	DIRECTION,
	ACTING,
	MARKETING,
	SALES,
	SALES_MARKETING
}
