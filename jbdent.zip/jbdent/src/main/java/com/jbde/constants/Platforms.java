package com.jbde.constants;

public enum Platforms {
	YOUTUBE,
	INSTAGRAM,
	FACEBOOK,
	TWITTER,
	MOJ,
	SHARECHAT,
	JOSH,
	TIKTOK,
	PINTEREST,
	SNAPCHAT
}
