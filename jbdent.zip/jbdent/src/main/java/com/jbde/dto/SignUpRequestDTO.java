package com.jbde.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignUpRequestDTO {

	private String suempID;
	private String suempName;
	private String suempEmail;
	private String suempPassword;
	private String suempRole;
	
}
