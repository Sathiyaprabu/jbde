/**
 *
 */
package com.jbde.dto;

import lombok.Getter;
import lombok.Setter;

/**
 *
 */
@Getter
@Setter
public class LoginRequestDTO {
	
	public String empLoginEmail;
	public String empLoginPassword;
	
	//public int empAge;
	//public int empExperience;
	//public StringBuilder empDepartment;

}
