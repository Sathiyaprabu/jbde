/**
 * 
 */
package com.jbde.employee;

/**
 * 
 */
public interface OnboardEmployee {
	public void employeeType();
	public void employeeJoiningDetails();
	public void employeePersonalDetails();
	public void employeeDocumentsUpload();
	public void employeeAddress();
}
